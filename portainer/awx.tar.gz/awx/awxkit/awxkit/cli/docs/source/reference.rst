.. autoprogram:: awxkit.cli.sphinx:parser
    :prog: awx
    :maxdepth: 3
