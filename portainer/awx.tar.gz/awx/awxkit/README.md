awxkit
======

A Python library that backs the provided `awx` command line client.

It can be installed by running `pip install awxkit`.

The PyPI respository can be found [here](https://pypi.org/project/awxkit/).

For more information on installing the CLI and building the docs on how to use it, look [here](./awxkit/cli/docs).