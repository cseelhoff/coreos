export { default } from './JobDetail';
