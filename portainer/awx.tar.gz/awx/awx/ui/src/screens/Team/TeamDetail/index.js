export { default } from './TeamDetail';
