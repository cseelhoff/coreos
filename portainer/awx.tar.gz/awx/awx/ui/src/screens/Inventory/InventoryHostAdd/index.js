export { default } from './InventoryHostAdd';
