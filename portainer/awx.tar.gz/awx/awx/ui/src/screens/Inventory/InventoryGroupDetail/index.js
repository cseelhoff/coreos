export { default } from './InventoryGroupDetail';
