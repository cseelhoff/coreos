export { default } from './InventoryAdd';
