export { default } from './InventoryHostList';
