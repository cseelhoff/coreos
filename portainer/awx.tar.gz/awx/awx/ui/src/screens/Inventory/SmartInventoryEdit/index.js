export { default } from './SmartInventoryEdit';
