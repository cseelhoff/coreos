export { default } from './AdvancedInventoryHosts';
