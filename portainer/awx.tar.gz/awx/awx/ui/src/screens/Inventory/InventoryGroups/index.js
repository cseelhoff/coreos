export { default } from './InventoryGroups';
