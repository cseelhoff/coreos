export { default } from './ConstructedInventoryDetail';
