export { default } from './InventorySourceDetail';
