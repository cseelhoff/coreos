export { default } from './InventoryHostFacts';
