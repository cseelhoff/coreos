export { default } from './SmartInventoryDetail';
