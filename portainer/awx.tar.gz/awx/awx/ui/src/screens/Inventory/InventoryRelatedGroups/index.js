export { default } from './InventoryRelatedGroups';
