export { default } from './ConstructedInventoryAdd';
