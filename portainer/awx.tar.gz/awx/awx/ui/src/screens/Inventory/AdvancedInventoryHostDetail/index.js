export { default } from './AdvancedInventoryHostDetail';
