export { default } from './AdvancedInventoryHost';
