export { default } from './InventoryGroupHostAdd';
