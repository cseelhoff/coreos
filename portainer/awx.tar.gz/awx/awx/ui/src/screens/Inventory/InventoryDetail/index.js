export { default } from './InventoryDetail';
