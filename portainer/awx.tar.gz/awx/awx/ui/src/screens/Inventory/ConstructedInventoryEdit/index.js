export { default } from './ConstructedInventoryEdit';
