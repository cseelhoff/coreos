export { default } from './SmartInventoryAdd';
