export { default } from './InventoryHostGroups';
