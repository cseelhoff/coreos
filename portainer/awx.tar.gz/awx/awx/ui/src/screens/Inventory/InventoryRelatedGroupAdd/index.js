export { default } from './InventoryRelatedGroupAdd';
