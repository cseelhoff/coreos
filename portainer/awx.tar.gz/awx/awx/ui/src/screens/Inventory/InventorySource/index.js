export { default } from './InventorySource';
