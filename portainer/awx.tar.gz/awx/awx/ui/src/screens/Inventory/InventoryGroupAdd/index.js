export { default } from './InventoryGroupAdd';
