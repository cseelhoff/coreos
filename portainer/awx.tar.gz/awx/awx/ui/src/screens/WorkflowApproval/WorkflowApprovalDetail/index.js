export { default } from './WorkflowApprovalDetail';
