import WorkflowApprovalList from './WorkflowApprovalList';

export default WorkflowApprovalList;
export { default as WorkflowApprovalListItem } from './WorkflowApprovalListItem';
