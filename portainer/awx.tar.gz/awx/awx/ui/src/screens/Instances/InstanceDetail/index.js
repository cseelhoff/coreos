export { default } from './InstanceDetail';
