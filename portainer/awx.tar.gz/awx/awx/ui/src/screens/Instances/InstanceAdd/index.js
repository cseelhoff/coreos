export { default } from './InstanceAdd';
